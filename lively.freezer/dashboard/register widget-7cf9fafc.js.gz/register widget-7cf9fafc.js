System.register(['./__root_module__-7cbd94df.js', 'kld-intersections', './user-ui-9501eee5.js', './index-6dd3a7ed.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
