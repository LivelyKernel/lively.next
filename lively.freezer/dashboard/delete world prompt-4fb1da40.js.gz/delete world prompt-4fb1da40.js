System.register(['./__root_module__-37c88ebd.js', 'kld-intersections', './index-53f40a2c.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
