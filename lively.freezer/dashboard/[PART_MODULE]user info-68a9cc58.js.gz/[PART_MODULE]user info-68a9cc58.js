System.register(['./__root_module__-aa47e4cd.js', 'kld-intersections', './user-ui-a3f53bac.js', './index-67dc020a.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
