System.register(['./__root_module__-06ff41f6.js', 'kld-intersections', './index-2b842a27.js', './index-1eaba422.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
