System.register(['./__root_module__-dce2a509.js', 'kld-intersections', './index-7c60e27b.js', './index-0a258dcd.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
