System.register(['./__root_module__-db735625.js', './index-4222eff9.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
