System.register(['./__root_module__-dce2a509.js', 'kld-intersections', './index-0a258dcd.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
