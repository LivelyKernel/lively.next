System.register(['./__root_module__-6d2e743c.js', 'kld-intersections', './index-5fc44505.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
