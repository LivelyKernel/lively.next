System.register(['./__root_module__-cd530690.js', 'kld-intersections', './user-ui-956488c9.js', './index-e341c34b.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
