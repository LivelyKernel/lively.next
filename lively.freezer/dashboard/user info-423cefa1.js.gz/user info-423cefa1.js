System.register(['./__root_module__-64e296ea.js', 'kld-intersections', './index-2a6f00a9.js', './user-ui-494b4ae6.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
