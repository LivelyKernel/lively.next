System.register(['./__root_module__-46f2ff9c.js', 'kld-intersections', './index-6c27ba6c.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
