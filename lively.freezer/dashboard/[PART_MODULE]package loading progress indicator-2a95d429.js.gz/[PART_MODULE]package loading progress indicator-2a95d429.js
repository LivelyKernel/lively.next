System.register(['./__root_module__-aa47e4cd.js', 'kld-intersections', './index-f44a97a5.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
