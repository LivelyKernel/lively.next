System.register(['./__root_module__-5a58cfed.js', 'kld-intersections', './user-ui-f14b43d5.js', './index-0f8ae983.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
