System.register(['./__root_module__-cddb8267.js', 'kld-intersections', './index-5e61fbf0.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
