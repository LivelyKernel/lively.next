System.register(['./__root_module__-06ff41f6.js', 'kld-intersections', './index-1eaba422.js', './user-ui-538db77c.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
