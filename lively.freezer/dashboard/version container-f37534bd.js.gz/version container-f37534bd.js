System.register(['./__root_module__-fd8ea0c8.js', 'kld-intersections', './index-0b494524.js', './index-b8f51b00.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
