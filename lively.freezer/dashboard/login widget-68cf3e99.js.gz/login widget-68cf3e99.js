System.register(['./__root_module__-fd8ea0c8.js', 'kld-intersections', './index-b8f51b00.js', './user-ui-84db94da.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
