System.register(['./__root_module__-073d42f8.js', 'kld-intersections', './index-c0aa3ce5.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
