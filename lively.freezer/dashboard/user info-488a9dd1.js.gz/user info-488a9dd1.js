System.register(['./__root_module__-255c8c26.js', 'kld-intersections', './user-ui-5be04eba.js', './index-029212ef.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
