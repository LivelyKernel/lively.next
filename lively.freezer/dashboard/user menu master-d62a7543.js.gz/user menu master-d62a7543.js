System.register(['./__root_module__-db735625.js', './index-2260babb.js', './index-7ce4e91c.js', './editor-plugin-25872f24.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
