System.register(['./__root_module__-f418f9fd.js', 'lively.collab', 'kld-intersections', './index-e1bb9574.js', './index-c551f254.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
