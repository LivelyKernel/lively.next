System.register(['./__root_module__-896eff71.js', 'kld-intersections', './index-4b5fc10c.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
