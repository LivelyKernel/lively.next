System.register(['./__root_module__-f418f9fd.js', 'lively.collab', 'kld-intersections', './index-c551f254.js', './user-ui-983ba0be.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
