System.register(['./__root_module__-64e296ea.js', 'kld-intersections', './index-1222f918.js', './editor-plugin-c8470ec8.js', './index-9c46491a.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
