System.register(['./__root_module__-64e296ea.js', 'kld-intersections', './index-2a6f00a9.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
