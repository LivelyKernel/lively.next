System.register(['./__root_module__-7efb35ac.js', 'kld-intersections', './user-ui-a91f8c15.js', './index-be7ef9ed.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
