System.register(['./__root_module__-dce2a509.js', 'kld-intersections', './index-0a258dcd.js', './user-ui-2b4d12a6.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
