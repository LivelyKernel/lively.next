System.register(['./__root_module__-64e296ea.js', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bZ);
		}, function () {}],
		execute: function () {



		}
	};
});
