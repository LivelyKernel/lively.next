System.register(['./__root_module__-f418f9fd.js', 'lively.collab', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bX);
		}, function () {}, function () {}],
		execute: function () {



		}
	};
});
