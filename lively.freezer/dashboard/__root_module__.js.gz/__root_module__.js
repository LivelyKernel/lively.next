System.register(['./__root_module__-aa47e4cd.js', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bX);
		}, function () {}],
		execute: function () {



		}
	};
});
