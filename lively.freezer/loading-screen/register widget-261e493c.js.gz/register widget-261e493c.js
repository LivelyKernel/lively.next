System.register(['./__root_module__-a4bfb546.js', 'kld-intersections', './index-5e766f8e.js', './user-ui-ad7092aa.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
