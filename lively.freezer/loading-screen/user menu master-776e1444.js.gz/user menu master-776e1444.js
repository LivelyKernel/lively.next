System.register(['./__root_module__-89b08ab2.js', 'kld-intersections', './index-1502344e.js', './editor-plugin-a483404a.js', './index-b806b9af.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
