System.register(['./__root_module__-a4bfb546.js', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bU);
		}, function () {}],
		execute: function () {



		}
	};
});
