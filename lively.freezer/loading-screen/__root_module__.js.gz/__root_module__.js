System.register(['./__root_module__-89b08ab2.js', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bX);
		}, function () {}],
		execute: function () {



		}
	};
});
