System.register(['./__root_module__-f9290433.js', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bV);
		}, function () {}],
		execute: function () {



		}
	};
});
