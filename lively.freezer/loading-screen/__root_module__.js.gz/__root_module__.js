System.register(['./__root_module__-7d53b604.js', 'lively.collab', 'kld-intersections'], function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.bV);
		}, function () {}, function () {}],
		execute: function () {



		}
	};
});
