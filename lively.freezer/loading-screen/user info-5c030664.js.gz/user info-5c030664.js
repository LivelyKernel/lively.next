System.register(['./__root_module__-89b08ab2.js', 'kld-intersections', './index-4f78f9ac.js', './user-ui-281b954b.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
