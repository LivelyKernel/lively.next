System.register(['./__root_module__-c4d7431e.js', 'kld-intersections', './user-ui-1bab221a.js', './index-6f8f5c35.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
