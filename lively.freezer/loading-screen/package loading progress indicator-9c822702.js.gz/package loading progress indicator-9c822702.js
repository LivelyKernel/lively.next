System.register(['./__root_module__-89b08ab2.js', 'kld-intersections'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
