System.register([], function () {
	'use strict';
	return {
		execute: function () {

			const __varRecorder__ = lively.FreezerRuntime.recorderFor("lively.2lively/index.js");

		}
	};
});
