System.register(['./__root_module__-f9290433.js', 'kld-intersections'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
