System.register(['./__root_module__-11543d52.js', 'kld-intersections', './user-ui-7ca0ad68.js', './editor-plugin-96b552ff.js', './index-82fd0049.js', './index-80650824.js', './index-58a61ed4.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
