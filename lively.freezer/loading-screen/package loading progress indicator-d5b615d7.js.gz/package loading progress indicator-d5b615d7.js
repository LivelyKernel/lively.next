System.register(['./__root_module__-c4d7431e.js', 'kld-intersections'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
