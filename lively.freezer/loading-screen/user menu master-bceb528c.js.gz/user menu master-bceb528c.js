System.register(['./__root_module__-be0d56fe.js', './index-2aae95d3.js', './index-6e2ebca5.js', './editor-plugin-d9aace66.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
