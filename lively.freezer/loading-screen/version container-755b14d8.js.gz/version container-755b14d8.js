System.register(['./__root_module__-be0d56fe.js', './index-a225ba89.js', './index-35f291db.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
