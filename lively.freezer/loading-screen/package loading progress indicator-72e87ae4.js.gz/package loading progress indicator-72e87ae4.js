System.register(['./__root_module__-3c9a1ccb.js', 'kld-intersections'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
