System.register(['./__root_module__-f9290433.js', 'kld-intersections', './user-ui-f9ff2404.js', './editor-plugin-70198a84.js', './index-9e4ab300.js', './index-5ea42d9a.js', './index-6fbfb2e6.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
