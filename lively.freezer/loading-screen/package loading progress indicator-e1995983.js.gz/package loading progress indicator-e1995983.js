System.register(['./__root_module__-28353364.js'], function () {
	'use strict';
	return {
		setters: [function () {}],
		execute: function () {



		}
	};
});
