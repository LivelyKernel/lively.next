System.register(['./__root_module__-590131e3.js'], function () {
	'use strict';
	return {
		setters: [function () {}],
		execute: function () {



		}
	};
});
