System.register(['./__root_module__-7d53b604.js', 'lively.collab', 'kld-intersections', './index-42dc99f4.js', './index-6ffa137d.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
