System.register(['./__root_module__-2cc1f5a8.js', './user-ui-b2bf1033.js', './index-b9082308.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
