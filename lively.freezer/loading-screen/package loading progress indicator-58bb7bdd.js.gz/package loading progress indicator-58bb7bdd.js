System.register(['./__root_module__-be0d56fe.js'], function () {
	'use strict';
	return {
		setters: [function () {}],
		execute: function () {



		}
	};
});
