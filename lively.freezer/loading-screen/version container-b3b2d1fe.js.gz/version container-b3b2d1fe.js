System.register(['./__root_module__-c4f77fb9.js', 'kld-intersections', './index-f69ab412.js', './index-cb8cbefd.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
