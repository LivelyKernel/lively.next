System.register(['./__root_module__-590131e3.js', './index-10a530fb.js', './index-ccd3ae79.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
