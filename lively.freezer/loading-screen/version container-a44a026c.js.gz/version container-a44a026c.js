System.register(['./__root_module__-a4bfb546.js', 'kld-intersections', './index-8925a56f.js', './index-5e766f8e.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
