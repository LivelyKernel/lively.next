System.register(['./__root_module__-cc486366.js', 'kld-intersections', './index-8abf3648.js', './user-ui-58858c09.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
