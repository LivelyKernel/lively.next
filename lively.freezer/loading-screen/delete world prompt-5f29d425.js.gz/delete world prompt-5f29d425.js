System.register(['./__root_module__-19078926.js', './index-20301cd6.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
