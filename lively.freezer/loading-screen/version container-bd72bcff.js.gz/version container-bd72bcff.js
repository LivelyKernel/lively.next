System.register(['./__root_module__-7487a13e.js', 'kld-intersections', './index-e37496ed.js', './index-014f5f9e.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
