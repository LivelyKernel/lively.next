System.register(['./__root_module__-82dea728.js', 'kld-intersections', './index-ebb6b2cb.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
