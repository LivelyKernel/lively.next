System.register(['./__root_module__-28353364.js', './object-classes-d1bf095f.js', './user-ui-49874e7c.js', './index-2112d28c.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
