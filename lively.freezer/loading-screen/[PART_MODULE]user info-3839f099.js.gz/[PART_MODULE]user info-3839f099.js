System.register(['./__root_module__-f9290433.js', 'kld-intersections', './user-ui-f9ff2404.js', './index-67954004.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
