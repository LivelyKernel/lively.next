System.register(['./__root_module__-2cc1f5a8.js', './index-121b2137.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
