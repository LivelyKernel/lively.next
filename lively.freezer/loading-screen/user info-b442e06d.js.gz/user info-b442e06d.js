System.register(['./__root_module__-3c9a1ccb.js', 'kld-intersections', './user-ui-6ad469c6.js', './index-443b373b.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
