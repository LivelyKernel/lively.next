System.register(['./__root_module__-1334cd4d.js', 'kld-intersections', './index-3ad28c75.js', './index-d1e6e603.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
