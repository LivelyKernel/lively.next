System.register(['./__root_module__-1334cd4d.js', 'kld-intersections', './index-d1e6e603.js', './user-ui-37d8182b.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
