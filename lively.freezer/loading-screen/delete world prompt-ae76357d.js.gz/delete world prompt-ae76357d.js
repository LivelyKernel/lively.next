System.register(['./__root_module__-be0d56fe.js', './index-35f291db.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
