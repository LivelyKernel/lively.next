System.register(['./__root_module__-884b54f8.js', 'kld-intersections', './index-46ea5601.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
