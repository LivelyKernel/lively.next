System.register(['./__root_module__-590131e3.js', './object-classes-19c034e8.js', './user-ui-f568f4c6.js', './index-ccd3ae79.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
