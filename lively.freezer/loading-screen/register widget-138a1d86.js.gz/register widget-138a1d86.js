System.register(['./__root_module__-82dea728.js', 'kld-intersections', './index-ebb6b2cb.js', './user-ui-4487d256.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
