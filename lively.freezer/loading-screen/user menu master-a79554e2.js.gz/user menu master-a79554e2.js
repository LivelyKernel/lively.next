System.register(['./__root_module__-590131e3.js', './index-2bc8c0f4.js', './index-1bb77cad.js', './editor-plugin-956fead1.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
