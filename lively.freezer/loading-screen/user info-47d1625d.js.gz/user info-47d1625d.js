System.register(['./__root_module__-be0d56fe.js', './object-classes-f8189235.js', './user-ui-f81a22e7.js', './index-35f291db.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
