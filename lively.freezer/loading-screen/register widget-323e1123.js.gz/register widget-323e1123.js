System.register(['./__root_module__-3d4e820f.js', 'kld-intersections', './user-ui-0b738134.js', './index-da7fb446.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
