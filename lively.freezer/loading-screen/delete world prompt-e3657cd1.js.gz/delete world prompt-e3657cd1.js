System.register(['./__root_module__-28353364.js', './index-2112d28c.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
