System.register(['./__root_module__-39b2be6e.js', 'lively.collab', 'kld-intersections', './index-906d9efb.js', './user-ui-ad881150.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
