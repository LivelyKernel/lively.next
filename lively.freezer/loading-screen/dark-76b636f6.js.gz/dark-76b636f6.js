System.register(['./__root_module__-19078926.js', './user-ui-3de50906.js', './index-879c50c1.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
