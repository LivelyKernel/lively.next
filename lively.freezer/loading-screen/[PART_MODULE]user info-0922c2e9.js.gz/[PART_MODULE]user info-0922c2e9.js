System.register(['./__root_module__-11543d52.js', 'kld-intersections', './user-ui-7ca0ad68.js', './index-5413fdc6.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
