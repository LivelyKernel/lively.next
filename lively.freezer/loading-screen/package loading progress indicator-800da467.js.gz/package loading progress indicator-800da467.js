System.register(['./__root_module__-884b54f8.js', 'kld-intersections'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}],
		execute: function () {



		}
	};
});
