System.register(['./__root_module__-7487a13e.js', 'kld-intersections', './index-014f5f9e.js', './user-ui-bdc9c3b3.js'], function () {
	'use strict';
	return {
		setters: [function () {}, function () {}, function () {}, function () {}],
		execute: function () {



		}
	};
});
